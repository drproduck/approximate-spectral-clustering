% function B = diagconjugate(A,D)
%
% Input: A square sparse matrix, D vector
%
% Output: B = diag(D)*A*diag(D)

error ('diagconjugate not found') ;
