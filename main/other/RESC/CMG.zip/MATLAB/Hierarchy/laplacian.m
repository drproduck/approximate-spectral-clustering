function L = laplacian(A)

d=diag(sum(A));
L = d-A;



      
      

